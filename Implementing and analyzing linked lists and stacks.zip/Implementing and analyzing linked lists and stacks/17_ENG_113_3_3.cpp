#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

//creating node 
struct Node
{
	int data;
	Node * Next;
};

//using class stack
class Stack
{
private:
	Node* top;
public:
	Stack() // constructor
	{
		top = NULL;
	}
	int isEmpty();
	void push(); // to insert an element
	void pop();  // to delete an element
	void show(); // to show the elements
	void reverse(); //to reverse the order of the elements
	void count(); //count the number of elements in the stack
	void Delete();  //delete the whole stack
};

//function to insert the elements
void Stack::push()
{
	int val;
	cout << "\n PUSH Operationn";
	cout << " Enter a number to insert: ";
	cin >> val;
	Node *ptr = new Node;
	ptr->data = val;
	ptr->Next = NULL;
	if (top != NULL)
		ptr->Next = top;
	top = ptr;
	cout << "\n New item is inserted to the stack!!!";

}

//function to delete the elements
void Stack::pop()
{
	Node * temp;
	if (top == NULL)
	{
		cout << "\n The stack is empty!!!";
	}
	else
	{
		temp = top;
		top = top->Next;
		temp->Next = NULL;
		cout << "\nPOP Operation........\nPoped value is " << temp->data;
		delete temp;
	}
}

//function to print the elements
void Stack::show()
{
	 Node* ptr1 = top;
	cout << "\nThe stack is\n";
	while (ptr1 != NULL)
	{
		cout << ptr1->data << " ->";
		ptr1 = ptr1->Next;
	}
	cout << "NULL\n";
}

//function to check whether the stack is empty or not
int Stack :: isEmpty()
{
	return top == NULL;
}

//function to reverse the stack
void Stack::reverse()
{
	if (top != NULL)
	{
		Node* tem = top;
		top = top->Next;
		Node* tem1 = top->Next;
		tem->Next = NULL;
		top->Next = tem;

		while (tem1 != NULL)
		{
			tem = top;
			top = tem1;
			tem1 = top->Next;
	        top->Next = tem;

		}

	}

}

// function to count the number of elements in the stack
void Stack::count()
{
	int i = 0;
	while (top != NULL)
	{
		top = top->Next;
		i = i + 1;

	}
	cout << i << endl;
}

//function to delete the whole stack
void Stack::Delete()
{

	while (top != NULL)
	{
		top = top->Next;
	}

}



int main()
{
		Stack s;
		int choice;
		while (1)
		{
			cout << "\n-----------------------------------------------------------";
			cout << "\n\t\tSTACK USING LINKED LIST\n\n";
			cout << "1:PUSH\n2:POP\n3:PRINT THE STACK\n4:REVERSE THE STSACK\n5:COUNT THE ELEMENTS IN THE STACK\n6:DELETE THE STACK\n7:EXIT" << endl<<endl;
			cout << "------------------------------------------------------------";
			cout << endl << endl << endl << endl;
			cout << "\nEnter your choice(1-7): ";
			cin >> choice;
			switch (choice)
			{
			case 1:
				s.push();
				break;
			case 2:
				s.pop();
				break;
			case 3:
				s.show();
				break;
			case 4:
				s.reverse();
			case 5:
				s.count();
				break;
			case 6:
				s.Delete();
				break;
			case 7:
				return 0;
				break;
			default:
				cout << "\n Please enter correct choice(1-7)!!";
				break;
			}

		}
	

	system("pause");
	return 0;
}



