#include <iostream>
using namespace std;

// creating a Node
struct Node
{
	int data;
	Node* Next;
};

//class for the linked lists
class LinkedList
{

public:
	
	Node* Head =NULL;
	void InsEnd(int new_data);
	void Intersect(Node* head1, Node* head2);
	bool Duplicates(Node*, int);
	void print();                                                 
};

//here we have to insert new data to the end
//function to enter new data to the end
void LinkedList::InsEnd(int newdata)
{

	Node* NewNode = new Node();

	Node* last = Head;
	NewNode->data = newdata;
	NewNode->Next = NULL;

	if (Head == NULL)
	{
		Head = NewNode;
		return;
	}
	else
	{
		while (last->Next != NULL)
			last = last->Next;

		last->Next = NewNode;
		return;
	}
	
}

//check whether inntersects the two linked lists
void LinkedList::Intersect(Node* Head1, Node* Head2)
{
	bool i, j;
	i = Duplicates(Head1, 1);
	j = Duplicates(Head2, 2);

	if (i == 1 || j == 1) 
	{
		return;
	}

	Node* Node1 = Head1;

	//Traveserse in the list 1 and list 2
	//if the val is present it is inserted in to the list
	while (Node1 != NULL)
	{
		Node* Node2 = Head2;
		while (Node2 != NULL)
		{
			if (Node2->data == Node1->data) 
			{
				InsEnd(Node1->data);
			}
			Node2 = Node2->Next;
		}

		Node1 = Node1->Next;
	}
	cout << "\n These are the common values for the two functions: ";
	print();
}


//function to find duplicates
bool LinkedList::Duplicates(Node* H, int x)
{
	Node* pointer1;
	Node* Pointer2; 
	pointer1 = H;

	// Pick the elements one by one 
	while (pointer1 != NULL && pointer1->Next != NULL)
	{
		Pointer2 = pointer1;

		// Compare the picked element with rest of the elements 
		while (Pointer2->Next != NULL)
		{
			// If duplicates are found then delete it 
			if (pointer1->data == Pointer2->Next->data)
			{
				// sequence of steps is important here 

				cout << "error : list " << x << " has copies of " << pointer1->data;
				cout << "\n";
				return 1;
				 Pointer2= Pointer2->Next;

			}
			else
			{
				Pointer2 = Pointer2->Next;
			}
		}
		pointer1 = pointer1->Next;
	}
	return 0;
}


//function to print the linked lists
void LinkedList::print()
{
	cout << " The list is " << endl;
	Node* ptr = Head;
	while (Head != NULL)
	{
		cout << Head->data;
		cout << endl;
		Head = Head->Next;
	}
	cout << endl;
}



	int main() 
	{
		LinkedList arr[2];
		LinkedList s;

		// lines to enter values for two liked lists 
		int number, values;
		for (int i = 0; i <=1; i++)
		{
			cout << " Please input the number of nodes in the linked list" << i + 1 << " :: ";
			cin >> number;

			for (int a = 0; a < number; a++) 
			{
				cout << " Please input the values for node" << a + 1 << " :: ";
				cin >> values;
				arr[i].InsEnd(values);

			}

			cout << endl;

		}
		// this will print out the entered values 
		for (int i = 0; i < 2; i++) {
			cout << " enter list " << i + 1 << " values : "; arr[i].print();
			cout << "\n ";
		}

		s.Intersect(arr[0].Head, arr[1].Head);

		cout << endl;
		system("pause");
		return 0;
	}
