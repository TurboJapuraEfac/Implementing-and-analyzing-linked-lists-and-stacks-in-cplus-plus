#include <iostream>
using namespace std;

//using struct to create a node
struct Node
{
	int data;
	Node * Next;
};

//class for the linked list
class LinkedList
{
private:
	Node* Head,*tail;
public:
	LinkedList()
	{
		Head = NULL;
		tail = NULL;
	}

	void createNode(int x);
	void insertBeg(int d);//Insert a new node at the beginning
	void insertEnd(int d); //Insert a node at the end
	void deleteBeg(); //Delete a node from the beginning
	void deleteEnd(); //Delete a node from the end
	void deleteGivanVal(int D); //Delete a node with a given value
	void  print(); //Print current list
	Node* search(int F); //Search an existing element in the list
	int sumof(struct Node* head); //Add list values to get sum
	bool empty();
};

//function for the creating a node
void LinkedList:: createNode(int x)
{
	Node* temp = new Node;
	temp->data = x;
	temp->Next = NULL;
	if (Head == NULL)
	{
		Head = temp;
		tail = temp;
		temp = NULL;
	}
	else
	{
		temp->Next = tail;
		tail = temp;
	}
}

//checking whether the function is empty or not
bool LinkedList::empty()
{
	return (Head == NULL);
}



//function to insert a node at the beginnig
void LinkedList::insertBeg(int d)
{	
	
		Node* ptr = new Node();
		ptr->data = d;
		ptr->Next = Head;
		Head= ptr;
	
}

//function to insert a node at the end
void LinkedList::insertEnd(int d)
{

		Node* ptr = new Node();
		ptr->data = d;
		ptr->Next = NULL;

		//If list is empty
		if (Head == NULL)
			Head = ptr;
		//else list is not empty
		else
		{
			Node* temp = Head;
			while (temp->Next != NULL)
			{
				temp = temp->Next;
			}
			temp->Next = ptr;

		}
}

//function to delelte the 1st node 
void LinkedList::deleteBeg()
{
    	//if list is empty.
		if (Head == NULL)
			cout << "LIST IS EMPTY\n";
		else
		{
			Node* ptr = Head;
			Head = Head->Next;
			free(ptr);

		}
}

// function to delelte the last node
void LinkedList::deleteEnd()
{
	
		Node* ptr, * pre;
		ptr = Head;
		pre = ptr;
		while (ptr->Next != NULL)
		{
			pre = ptr;
			ptr = ptr->Next;
		}
		pre->Next = NULL;
		delete ptr;
}

//function to delete the node which includes the given value
void LinkedList::deleteGivanVal(int D)
{
	
		Node* current = new Node;
		Node* previous = new Node;
		current = Head;
		for (int i = 1; i < D; i++)
		{
			previous = current;
			current = current->Next;
		}
		previous->Next = current->Next;
	
}

//checks whether the value is present in the list
Node* LinkedList::search(int x)
{
	Node* node = Head;

	while (node != NULL)
	{
		if (node->data == x) 
			// This will use the == operator in ListNode
			return node;
		node = node->Next;
	}
	return NULL;  
	// not found
}

// the function to print the list
void LinkedList::print ()
{
	cout << " The list is " << endl;
	Node* ptr = Head;
	while (Head!= NULL)
	{
		cout << Head->data;
		cout << endl;
		Head= Head->Next;
	}
	cout << endl;
}


//The function to get the sum of the nodes 
void sumofrec(struct Node* head, int* sum)
{
	// if head = NULL 
	if (!head)
		return;

	// recursively traverse the remaining nodes 
	sumofrec(head->Next, sum);

	// accumulate sum 
	*sum = *sum + head->data;
}


// utility function to find the sum of  nodes 
int LinkedList:: sumof(struct Node* head)
{

	int sum = 0;

	// find the sum of  nodes 
	sumofrec(head, &sum);

	// required sum 
	return sum;
}


int menu();

int main()
{
	int select;
	LinkedList A; //creating an object
	Node* Head = NULL;

	cout << "How many numbers do you want:";
	int n, i, x;
	scanf_s("%d", &n);

	for (i = 0; i < n; i++)
	{
		cout << "Enter the numbers :";
		scanf_s("%d", &x);
		A.insertBeg(x);
	}

	

	do
	{
		select = menu();
		cout << endl;
		switch (select)
		{
		case 0:
		{
			cout << "Good-bye!\n";
			break;
		}
		case 1:
		{
			cout << " Please enter the number that you want to enter at the beginning:";
			int x;
			cin >> x;

			A.insertBeg(x); // Insert after last search (or head if no search)
			Head = NULL;  // Reset result
			cout << "Integer inserted into list.\n";
			break;
		}

		case 2:
		{
			cout << " Please enter the number that you want to enter at the end:";
			int x;
			cin >> x;
			A.insertEnd(x);
			
			break;
		}
		case 3:
		{
			cout << " You are deleting the 1st node" << endl;
			A.deleteBeg();
			A.print();
			break;
		}
		case 4:
		{
			cout << " You are deleting the last node" << endl;
			A.deleteEnd();
	
			break;
		}

		case 5:
		{
			cout << " Please enter the number that you want to delete:";
			int D;
			cin >> D;
			A.deleteGivanVal(D);
			
			break;
		}

		case 6:
		{
			cout << " The linked list is:" << endl;
			A.print();
		}

		case 7:
		{
			cout << "Please enter the number that you want to search:";
			int c;
			cin >> c;

			Head = A.search(c);
			if (Head == NULL)
			{
				cout << "Integer not found in list.\n";
			}
			else
			{
				cout << "Integer found in list at address " << Head << ".\n";
			}
			break;
		}
		case 8:
		{

			A.sumof(Head);
			break;
		}
		default:
			cout << "Error: Invalid menu selection.\n";
		}
		cout << endl;
	} while (select!= 0);

	system("pause");
	return 0;
}


// function to print the menu that we use
int menu()
{
	int sel;

	cout << "      Welcome to the Linked List Menu\n";
	cout << "\n\n\n\n ==============================================================================" << endl;
	cout << "        1 - Insert Beginning" << endl;
	cout << "	2 - Insert End" << endl;
	cout << "	3 - Delete Beginning" << endl;
	cout << "	4 - Delete End" << endl;
	cout << "	5 - Delete Value" << endl;
	cout << "	6 - Print" << endl;
	cout << "	7 - Search" << endl;
	cout << "	8 - Sum" << endl;
	cout << "	Enter Your Choice :" << endl;
	cout << "================================================================================" << endl;

	cin >> sel;
	while (cin.fail())
	{
		cin.clear();
		cin.ignore(20, '\n');
		cout << "  Error: Selection must be an integer." << endl;
		cout << " Enter the selection" << endl;
		cin >> sel;
	}

	return sel;


	system("pause");
	return 0;
}