#include <iostream>
using namespace std;

// creating a node
class Node
{
public:
	char data;
	Node * Next;
};

//creating a class stack 
class Stack
{
private:
	Node* top;
public:
	Stack() // constructor
	{
		top = NULL;
	}
	
	void push(char A); // to insert an element
	void pop();  // to delete an element
	bool Equation(string A);

	void show(); // to show the elements
	
};

//inserting elements in to the stack
void Stack::push(char A)
{
	Node *ptr = new Node;
	ptr->data = A;
	ptr->Next = NULL;
	if (top != NULL)
		ptr->Next = top;
	top = ptr;
}

//deleting elements from the stack
void Stack::pop()
{
	Node * temp;
	if (top == NULL)
	{
		cout << "\n The stack is empty!!!";
	}
	else
	{
		temp = top;
		top = top->Next;
		temp->Next = NULL;
		cout << " Deleted value is::" << temp->data;
		delete temp;
	}
}

//checking whwether the brackets are eqaul 
bool Stack::Equation(string A)
{

	for (int i = 0; i < A.length(); i++)
	{
		if (A[i] == '(' || A[i] == '[' || A[i] == '{')
		{
			push(A[i]);//inserting the starting brackets
		}

		if(A[i]== ')') //checking closing brackets and deleting them
		{
			char a = top->data;
			pop();
			if (a == '[' || a == '{')
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		else if(A[i]=='}')//checking closing brackets and deleting them
	    {
			char a = top->data;
			pop();
			if (a == '[' || a == '(')
			{
				return false;
			}
			else
			{
				return true;
			}
			break;

		}

	    else if(A[i]==']')//checking closing brackets and deleting them
		{
			char a = top->data;
			pop();
			if (a == '(' || a == '{')
			{
				return false;
			}
			else
			{
				return true;
			}
			break;
		}

		else
		{
			break;
		}

	}
	if (top != NULL)
	{
		return false;

	}
	else
	{
		return true;
	}
}

//function to print the elemnts
void Stack::show()
{
	 Node* ptr1 = top;
	cout << "\n The stack is::";
	while (ptr1 != NULL)
	{
		cout << ptr1->data << " ->";
		ptr1 = ptr1->Next;
	}
	cout << " NULL\n ";
}

int main()
{
	Stack S;
	string the_expression;
	cout << " Enter an expression:  "; 
	cin>>the_expression;

	bool A;
	A = S.Equation(the_expression);
	if (A == 0)
	{
		cout << " Brackets are not balanced :" << endl;
	}
	else
	{
		cout << " Bracket are balanced :" << endl;
	}
	system("pause");
	return 0;
}



